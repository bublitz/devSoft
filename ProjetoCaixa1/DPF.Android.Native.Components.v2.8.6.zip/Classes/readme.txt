this file (classes.dex) merged with Delphi XE7
If you have XE6 you must be make it again with your Delphi classes.dex file
(or send me your updated Delphi classes.dex to make it again and publish into site)
