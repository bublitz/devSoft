For using Calendar Alarm Demo, after deploying into Device, if you are using iOS 6 and later 
you must be ON Calendar Privacy.