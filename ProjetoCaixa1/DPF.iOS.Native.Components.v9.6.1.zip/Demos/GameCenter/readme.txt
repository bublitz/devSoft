
 1. In iTunes connect ensure that you have a unique App ID
 2. Create a new application and update application information. You can know more about this in apple add new apps documentation.
 3. Setup a leader board in Manage Game Center of your application's page where add a single leaderboard and give leaderboard ID and score Type. Here we give leader board ID as DPFLeaderboard.
 4. Setup a Achievement in Manage Game Center of your application's page where add a single Achievement and give leaderboard ID and score Type. Here we give Achievement ID as DPFAchievementID.
 5. Enter the bundle identifier is the identifier specified in iTunes connect. (very important)
    
    Delphi->Project->Options...->Version Info->CFBundleIdentifier = YOUR iTunesconnect App Bundle ID
-------------------
 Babak Yaghoobi