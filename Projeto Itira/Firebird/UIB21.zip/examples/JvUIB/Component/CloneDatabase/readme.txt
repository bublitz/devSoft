This is a usefull tool to clone your databases for
- recover damaged database
- change ODS version

This sample can be easy modified to create your own backup format
(TSQLResult.SaveToStream() TMetaDataBase.SaveToStream() ... )