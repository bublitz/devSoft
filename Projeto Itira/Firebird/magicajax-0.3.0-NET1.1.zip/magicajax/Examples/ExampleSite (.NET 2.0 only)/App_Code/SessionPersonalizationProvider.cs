﻿using System;
using System.Web;
using System.Web.UI.WebControls.WebParts;
using System.Web.Hosting;

public class SessionPersonalizationProvider : PersonalizationProvider
{
	protected override void LoadPersonalizationBlobs(WebPartManager webPartManager, string path, string userName, ref byte[] sharedDataBlob, ref byte[] userDataBlob)
	{
		object blob = HttpContext.Current.Session[path];
		if (blob != null)
		{
			userDataBlob = (byte[])blob;
		}
	}

	protected override void ResetPersonalizationBlob(WebPartManager webPartManager, string path, string userName)
	{
		SavePersonalizationBlob(webPartManager, path, userName, null);
	}

	protected override void SavePersonalizationBlob(WebPartManager webPartManager, string path, string userName, byte[] dataBlob)
	{
		HttpContext.Current.Session.Add(path, dataBlob);
	}

	private string _applicationName;
	public override string ApplicationName
	{
		get
		{
			if (string.IsNullOrEmpty(_applicationName))
			{
				_applicationName = HostingEnvironment.ApplicationVirtualPath;
			}
			return _applicationName;
		}
		set
		{
			_applicationName = value;
		}
	}

	public override int GetCountOfState(PersonalizationScope scope, PersonalizationStateQuery query)
	{
		throw new NotImplementedException();
	}

	public override PersonalizationStateInfoCollection FindState(PersonalizationScope scope, PersonalizationStateQuery query, int pageIndex, int pageSize, out int totalRecords)
	{
		throw new NotImplementedException();
	}

	public override int ResetState(PersonalizationScope scope, string[] paths, string[] usernames)
	{
		throw new NotImplementedException();
	}

	public override int ResetUserState(string path, DateTime userInactiveSinceDate)
	{
		throw new NotImplementedException();
	}
}

