Step 1: create a virtual dir in IIS, and map to this folder 
        note: make sure the virtual dir runs with .NET 2.0.
Step 2: place MagicAjax.dll in the Bin folder

Now you should be able to run the demo pages
