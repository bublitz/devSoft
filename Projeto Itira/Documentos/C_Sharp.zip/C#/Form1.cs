using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WindowsApplication1
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(72, 8);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(128, 32);
			this.button1.TabIndex = 0;
			this.button1.Text = "Imprime Boleto";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.Add(this.button1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
		
// Este exemplo foi gentilmente constru�do pela equipe da
// BRONZE & BUSINESS INFORM�TICA LTDA - S�o Paulo - SP
// site: http://www.bronzebusiness.com.br
// Ao Henrique da BRONZE & BUSINESS INFORM�TICA os nossos agradecimentos

// Cria inst�ncia do objeto CobreBemX
CobreBemX.ContaCorrente _CobreBemX = new CobreBemX.ContaCorrenteClass();

// Monta arquivo de licen�a de teste para banco 001 carteira 18
_CobreBemX.ArquivoLicenca = @"c:\CobreBemX\Exemplos\Licencas\001-18.conf";

// Monta dados da conta corrente
_CobreBemX.CodigoAgencia = "1234-5";
_CobreBemX.NumeroContaCorrente = "00000123-X";
_CobreBemX.CodigoCedente = "123456";
_CobreBemX.OutroDadoConfiguracao1 = "019";
_CobreBemX.InicioNossoNumero = "00001";
_CobreBemX.FimNossoNumero = "99999";
_CobreBemX.ProximoNossoNumero = "00015";

_CobreBemX.PadroesBoleto.PadroesBoletoImpresso.ArquivoLogotipo = @"c:\CobreBemX\Imagens\logocbt.jpg";
_CobreBemX.PadroesBoleto.PadroesBoletoImpresso.CaminhoImagensCodigoBarras = @"c:\CobreBemX\Imagens\";
			
// Cria documento de cobran�a
CobreBemX.IDocumentoCobranca Boleto  = _CobreBemX.DocumentosCobranca.Add;

// Monta dados do sacado
Boleto.NomeSacado = "Fulano de Tal";

// Para PJ utilize CNPJSacado
Boleto.CPFSacado = "111.111.111-11";

Boleto.EnderecoSacado = "Rua do Sacado 123";
Boleto.BairroSacado = "Bairro do Sacado";
Boleto.CidadeSacado = "Cidade do Sacado";
Boleto.EstadoSacado = "SP";
Boleto.CepSacado = "01001-001";

// Monta dados do documento de cobran�a
Boleto.DataDocumento = DateTime.Now.ToShortDateString();

// Data de Vencimento 3 dias ap�s a data do servidor
Boleto.DataVencimento = DateTime.Now.AddDays(3).ToShortDateString();

Boleto.NumeroDocumento = "12345";
Boleto.ValorDocumento = 123.45;

Boleto.PadroesBoleto.Demonstrativo = "Referente a compras na WEB<br><b>O melhor site da Internet</b>";
Boleto.PadroesBoleto.InstrucoesCaixa = "<br><br>N�o cobrar juros e multa ap�s o vencimento";

// Solicita a gera��o do boleto e retorna-o como o resultado
_CobreBemX.ImprimeBoletos();

// Libera inst�ncia do objeto CobreBemX
_CobreBemX = null;

		}
	}
}
