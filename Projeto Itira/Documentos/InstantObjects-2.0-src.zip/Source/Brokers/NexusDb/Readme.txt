NexusDb Brokers for InstantObjects
Steven Mitchell - 29 Jul 2005

To use these brokers with NexusDB V1 set the compiler conditional define of "NX1" in the 'InstantNexusDBDefines.inc' file and (re)build all of the NexusDB related broker packages.

To use these brokers with NexusDB V2 comment the compiler conditional define of "NX1" in the 'InstantNexusDBDefines.inc' file and (re)build all of the NexusDB related broker packages.

The current default is to compile for NexusDB V2.

Note: Minimal testing has been done with NexusDB V2 as this version has only recently been released.