Firebird databases folder for Primer demos, if you are using default connection definitions.
