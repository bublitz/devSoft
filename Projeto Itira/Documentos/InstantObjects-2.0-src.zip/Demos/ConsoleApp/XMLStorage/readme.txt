XML storage folder for IOConsole demo.
